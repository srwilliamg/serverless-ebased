const sns = require("ebased/service/downstream/sns");

async function publishClientCreatedService(clientCreatedEvent) {
  const { eventPayload, eventMeta } = clientCreatedEvent.get();

  const snsPublishParams = {
    TopicArn: "arn:aws:sns:us-east-1:066987178365:client-created",
    Message: eventPayload,
  };

  await sns.publish(snsPublishParams, eventMeta);
}

module.exports = { publishClientCreatedService };
